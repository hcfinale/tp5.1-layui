<?php
/*
短信平台接口示例
开发文档：http://www.jsmsxx.com/api/http_doc

公司：江苏美圣信息技术有限公司
官网：http://www.jsmsxx.com
电话：4006000599
*/

class Sms{

    //客户请初始短信帐号参数
    private  $svr_param =  array("username"=>"JSM42416","password"=>"97e0r76z","veryCode"=>"i81x61zk25wb");

    //服务器参数设置
    private  $svr_url = 'http://112.74.76.186:8030/service/httpService/httpInterface.do';   // 服务器接口路径


    function __construct() {
        $this->sms();
    }

    function sms() {}

    // 1、获得余额
    public function getAmount(){
        $post_data =$this-> svr_param;
        $post_data['method'] = 'getAmount';
        $res =$this-> request_post($this-> svr_url,$post_data);
        return  $res;
    }

    // 2、发送普通短信，需要人工审核后才能发送，因此可能不会立刻收到
    public function sendTextMsg($mobile,$content,$code="utf-8")
    {
        $post_data =$this->svr_param;
        $post_data['method'] = 'sendMsg';
        $post_data['mobile'] = $mobile;
        $post_data['content']= $content;
        $post_data['msgtype']="1";  // 1-普通短信，2-模板短信
        $post_data['code']   =$code;   // utf-8,gbk
        $res =$this-> request_post($this->svr_url, $post_data);  // 如果账号开了免审，或者是做模板短信，将会按照规则正常发出，而不会进人工审核平台
        return $res;
    }

    // 3、发送模板短信
    //  短信模板管理中增加一个模板，编号为JSM40004-0000，内容为：尊敬的@1@你好,您在江苏美圣网站（www.jsmsxx.com），注册的手机验证码为@2@，请在验证页面及时输入。
    //  成功发送后，收到的信息形如：尊敬的包先生你好,您在江苏美圣网站（www.jsmsxx.com），注册的手机验证码为874382，请在验证页面及时输入。

    public function sendTplMsg($tplid,$mobile,$content,$code="utf-8"){
        $post_data = $this->svr_param;
        $post_data['method'] = 'sendMsg';//如果有乱码请尝试用 sendUtf8Msg 或  sendGbkMsg
        $post_data['mobile'] = $mobile;
        $post_data['content']=$content;// 或 "@1@=$code";
        $post_data['msgtype']= '2';    // 1-普通短信，2-模板短信
        $post_data['tempid'] =$tplid;  // 模板编号 ， 在客户创建模板后会生成模板编号
        $post_data['code']   = 'utf-8';// utf-8,gbk
        $res =$this-> request_post($this-> svr_url, $post_data);  // 如果账号开了免审，或者是做模板短信，将会按照规则正常发出，而不会进人工审核平台
        return $res;
    }

    // 4、获得状态报告
    //  只能查询当天的，已获取的状态报告后续不会再获取
    public function queryReport(){
        $post_data = $this-> svr_param;
        $post_data['method'] = 'queryReport';
        $res = $this-> request_post($this-> svr_url, $post_data);
        return $res;
    }

    // 5、获得上行短信
    //  只能查询当天的，已获取的上行短信后续不会再获取
    public function queryMo(){
        $post_data =  $this->svr_param;
        $post_data['method'] = 'queryMo';
        $res = $this-> request_post( $this-> svr_url, $post_data);
        return $res;
    }


    /**
     * 模拟post进行url请求
     * @param string $url
     * @param array $post_data
     */
    private  function request_post($url = '', $post_data = array()) {
        if (empty($url) || empty($post_data)) {
            return false;
        }

        $o = "";
        foreach ( $post_data as $k => $v )
        {
            $o.= "$k=" . urlencode( $v ). "&" ;
        }
        $post_data = substr($o,0,-1);

        $postUrl = $url;
        $curlPost = $post_data;
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);

        return $data;
    }


    // XML格式转数组格式
    function xml_to_array( $xml ) {
        $reg = "/<(\w+)[^>]*>([\\x00-\\xFF]*)<\\/\\1>/";
        if(preg_match_all($reg, $xml, $matches)) {
            $count = count($matches[0]);
            for($i = 0; $i < $count; $i++) {
                $subxml= $matches[2][$i];
                $key = $matches[1][$i];
                if(preg_match( $reg, $subxml )) {
                    $arr[$key] = xml_to_array( $subxml );
                } else {
                    $arr[$key] = $subxml;
                }
            }
        }
        return $arr;
    }

    // 页面显示数组格式，用于调试
    function echo_xmlarr($res) {
        $res = xml_to_array($res);
        echo "<pre>";
        print_r($res);
        echo "</pre>";
    }

}