<?php
/**
 * Created by PhpStorm.
 * User: wuh
 * Date: 2018/5/22
 * Time: 17:32
 */

class Map{
    public static function getLngLat($address){
        if(!$address){
            return '';
        }
        $data = [
            'address'   =>  $address,
            'ak'    =>  config('map.ak'),
            'output'    =>  'json',
        ];
        $url = config('map.baidu_map_url').config('map.geocoder').'?'.http_build_query($data);
        $resout = doCurl($url);
        return $resout;
    }

    /**
     * 根据经纬度或者地址获取百度地图
     */
    public static function staticimage($center){
        if(!$center){
            return '';
        }
        $data = [
            'ak'    =>  config('map.ak'),
            'width' =>  config('map.width'),
            'height' =>  config('map.height'),
            'center'    =>  $center,
            'markers'   =>  $center,
        ];
        $url = config('map.baidu_map_url').config('map.staticimage').'?'.http_build_query($data);
        $resout = doCurl($url);
        return $resout;
    }
}