function hc_move(title,url,w,h) {
    layer_show(title,url,w,h);
}
function hc_edit(title,url) {
    var index = layer.open({
        type:2,
        title:title,
        content:url
    });
    layer.full(index);
}
function hc_del(id,url) {
    layer.confirm('确认删除吗？',function (index) {
        window.location.href = url;
    })
}



function layer_show(title,url,w,h){
	if (title == null || title == '') {
		title=false;
	};
	if (url == null || url == '') {
		url="404.html";
	};
	if (w == null || w == '') {
		w=800;
	};
	if (h == null || h == '') {
		h=($(window).height() - 50);
	};
	layer.open({
		type: 2,
		area: [w+'px', h +'px'],
		fix: false, //不固定
		maxmin: true,
		shade:0.4,
		title: title,
		content: url
	});
}
/*关闭弹出框口*/
function layer_close(){
	var index = parent.layer.getFrameIndex(window.name);
	parent.layer.close(index);
}